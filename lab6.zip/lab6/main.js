console.log("Exercise 1");
console.log("Hello World!");
console.log("Hello World!");
console.log("Hello World!");


for (let i=0; i <3; i++) {
        console.log("hello world");
    }


console.log("Exercise 5");
let n1 = 4
let n2 = 8
if (n2 === 0) {
        console.log("Cannot divide by zero")
    } else {
        console.log(n1/n2)
    }



console.log("Exercise 10");
let num1 = 5
let num2 = 10
if (num1>num2) {
    console.log("num1 and num2 are not equal")
}
else if (num1==num2) {
    console.log("num1 and num2 are equal")
}
else {
    console.log("num1 and num2 are not equal")
}
